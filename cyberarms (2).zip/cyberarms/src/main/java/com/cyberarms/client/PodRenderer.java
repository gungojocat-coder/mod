package com.cyberarms.client;

import com.cyberarms.CyberArms;
import com.cyberarms.entity.SupportPodEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** geo/entity/support_pod.geo.json, animations/entity/support_pod.animation.json, textures/entity/support_pod.png */
public class PodRenderer extends GeoEntityRenderer<SupportPodEntity> {
    public PodRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new DefaultedEntityGeoModel<>(new ResourceLocation(CyberArms.MODID, "support_pod")));
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
        this.shadowRadius = 1.2f;
    }

    @Override
    public void render(SupportPodEntity pod, float yaw, float partialTick, PoseStack ps, MultiBufferSource buf, int light) {
        if (pod.getPhase() == SupportPodEntity.SIGNAL) return;   // only the red beacon column is visible until it drops
        super.render(pod, yaw, partialTick, ps, buf, light);
    }
}
