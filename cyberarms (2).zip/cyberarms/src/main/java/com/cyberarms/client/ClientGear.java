package com.cyberarms.client;

import com.cyberarms.data.CyberData;
import com.cyberarms.data.HardpointType;
import com.cyberarms.item.CoreItem;
import net.minecraft.nbt.CompoundTag;

import java.util.HashMap;
import java.util.Map;

/** Client-side copy of every visible player's gear + their GeckoLib animatables. */
public final class ClientGear {
    private static final Map<Integer, PlayerGear> GEAR = new HashMap<>();
    private ClientGear() {}

    public static final class PlayerGear {
        public final CyberData data = new CyberData();
        public final GearAnimatable core = new GearAnimatable("core");
        public GearAnimatable left, right, back;
        public int aimTicks;        // >0 while an arm cannon should be raised
        public int aimSlot = 1;     // which arm is aiming
        public float shownEnergy = CyberData.MAX_ENERGY;   // smoothed for the HUD

        private static GearAnimatable fit(GearAnimatable old, HardpointType t) {
            if (t == null) return null;
            return old != null && old.id.equals(t.id) ? old : new GearAnimatable(t.id);
        }
    }

    public static PlayerGear get(int entityId) { return GEAR.get(entityId); }

    public static void sync(int entityId, CompoundTag tag) {
        PlayerGear g = GEAR.computeIfAbsent(entityId, k -> new PlayerGear());
        g.data.deserializeNBT(tag);
        g.core.tint = 0xFF000000 | CoreItem.rgb(g.data.coreColor);
        g.left = PlayerGear.fit(g.left, g.data.left);
        g.right = PlayerGear.fit(g.right, g.data.right);
        g.back = PlayerGear.fit(g.back, g.data.back);
    }

    /** slot: 0 left arm, 1 right arm, 2 back */
    public static void anim(int entityId, int slot, String anim) {
        PlayerGear g = GEAR.get(entityId);
        if (g == null) return;
        GearAnimatable a = slot == 0 ? g.left : slot == 1 ? g.right : slot == 2 ? g.back : g.core;
        if (a != null) a.trigger(anim);
        if (slot < 2 && a != null && (anim.equals("fire") || anim.equals("skill") || anim.equals("signal"))) {
            if (a.id.endsWith("cannon") || anim.equals("signal")) {
                g.aimTicks = anim.equals("skill") ? 28 : 12;
                g.aimSlot = slot;
            }
        }
    }

    public static void tick() {
        for (PlayerGear g : GEAR.values()) {
            if (g.aimTicks > 0) g.aimTicks--;
            for (int i = 0; i < g.data.cooldowns.length; i++) if (g.data.cooldowns[i] > 0) g.data.cooldowns[i]--;
            if (g.data.supportCooldown > 0) g.data.supportCooldown--;
            if (g.data.overdriveTicks > 0) g.data.overdriveTicks--;
            if (g.data.overheatTicks > 0) g.data.overheatTicks--;
            g.shownEnergy += (g.data.energy - g.shownEnergy) * 0.25f;
        }
    }

    public static void clear() { GEAR.clear(); }
}
