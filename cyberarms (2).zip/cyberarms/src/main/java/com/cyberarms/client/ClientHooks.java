package com.cyberarms.client;

import net.minecraft.nbt.CompoundTag;

/** Entry points called from S2C packets (kept in the client package so the server never loads client classes). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void onSync(int entityId, CompoundTag tag) { if (tag != null) ClientGear.sync(entityId, tag); }

    public static void onAnim(int entityId, int slot, String anim) { ClientGear.anim(entityId, slot, anim); }
}
