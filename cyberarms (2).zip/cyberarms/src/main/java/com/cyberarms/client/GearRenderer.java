package com.cyberarms.client;

import com.cyberarms.CyberArms;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoObjectRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

import java.util.HashMap;
import java.util.Map;

/** GeckoLib renderer for worn gear. One instance per gear id (each has its own model files). */
public class GearRenderer extends GeoObjectRenderer<GearAnimatable> {
    private static final Map<String, GearRenderer> CACHE = new HashMap<>();

    public static GearRenderer of(String id) { return CACHE.computeIfAbsent(id, GearRenderer::new); }

    private GearRenderer(String id) {
        super(new Model(id));
        addRenderLayer(new AutoGlowingGeoLayer<>(this));   // uses <texture>_glowing.png as emissive layer
    }

    @Override
    public int getRenderColor(GearAnimatable animatable, float partialTick, int packedLight) {
        return animatable.tint;
    }

    /** assets/cyberarms/geo/gear/<id>.geo.json, animations/gear/<id>.animation.json, textures/gear/<id>.png */
    private static class Model extends GeoModel<GearAnimatable> {
        private final String id;
        Model(String id) { this.id = id; }

        @Override public ResourceLocation getModelResource(GearAnimatable a) {
            return new ResourceLocation(CyberArms.MODID, "geo/gear/" + id + ".geo.json");
        }
        @Override public ResourceLocation getTextureResource(GearAnimatable a) {
            return new ResourceLocation(CyberArms.MODID, "textures/gear/" + id + ".png");
        }
        @Override public ResourceLocation getAnimationResource(GearAnimatable a) {
            return new ResourceLocation(CyberArms.MODID, "animations/gear/" + id + ".animation.json");
        }
    }
}
