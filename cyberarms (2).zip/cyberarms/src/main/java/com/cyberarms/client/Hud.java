package com.cyberarms.client;

import com.cyberarms.data.CyberData;
import com.cyberarms.data.HardpointType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** Bottom-left status panel: energy, load, slots, cooldowns, overdrive / overheat / support. */
public final class Hud {
    private Hud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        ClientGear.PlayerGear pg = ClientGear.get(mc.player.getId());
        if (pg == null || !pg.data.hasCore) return;
        CyberData d = pg.data;
        Font font = mc.font;

        final int x = 10, barW = 130;
        int y = h - 92;
        long t = System.currentTimeMillis();
        boolean od = d.overdrive(), oh = d.overheated();

        // panel
        g.fill(x - 4, y - 4, x + barW + 6, h - 6, 0x90000812);
        g.fill(x - 4, y - 4, x - 2, h - 6, od ? 0xFFFFFFFF : oh ? 0xFFFF3030 : 0xFF27B5FF);

        // title
        Component title = Component.translatable(od ? "hud.cyberarms.overdrive" : oh ? "hud.cyberarms.overheat" : "hud.cyberarms.core");
        int tcol = od ? (((t / 120) % 2 == 0) ? 0xFFFFFFFF : 0xFF7FE0FF) : oh ? 0xFFFF5050 : 0xFF7FE0FF;
        g.drawString(font, title, x, y, tcol, true);
        if (od) g.drawString(font, (d.overdriveTicks / 20) + "s", x + barW - 20, y, 0xFFFFFFFF, true);
        else if (oh) g.drawString(font, (d.overheatTicks / 20 + 1) + "s", x + barW - 20, y, 0xFFFF5050, true);

        // energy bar
        y += 12;
        float e = Math.max(0, Math.min(1, pg.shownEnergy / CyberData.MAX_ENERGY));
        bar(g, x, y, barW, 7, e, od ? 0xFFFFFFFF : oh ? 0xFFFF3030 : e < 0.2f ? 0xFFFF8030 : 0xFF27B5FF);
        g.drawString(font, (int) d.energy + "/" + (int) CyberData.MAX_ENERGY, x + 2, y - 0, 0xFF000000, false);

        // load bar
        y += 11;
        int load = d.currentLoad();
        float lf = load / (float) CyberData.MAX_LOAD;
        bar(g, x, y, barW, 5, lf, lf > 0.85f ? 0xFFFFA030 : 0xFF50E080);
        g.drawString(font, Component.translatable("hud.cyberarms.load", load, CyberData.MAX_LOAD), x, y + 7, 0xFFB0C8D8, true);

        // slots with cooldown bars
        y += 20;
        slot(g, font, x, y, "L", d.left, d.cooldowns[CyberData.CD_FIRE_L], d.cooldowns[CyberData.CD_SKILL_L], barW);
        y += 11;
        slot(g, font, x, y, "R", d.right, d.cooldowns[CyberData.CD_FIRE_R], d.cooldowns[CyberData.CD_SKILL_R], barW);
        y += 11;
        slot(g, font, x, y, "B", d.back, 0, d.cooldowns[CyberData.CD_SKILL_B], barW);

        // support call
        y += 11;
        Component sup = d.supportCooldown > 0
                ? Component.translatable("hud.cyberarms.support_cd", d.supportCooldown / 20 + 1)
                : Component.translatable("hud.cyberarms.support_ready");
        g.drawString(font, sup, x, y, d.supportCooldown > 0 ? 0xFF8899AA : 0xFFFF6060, true);
    }

    private static void bar(GuiGraphics g, int x, int y, int w, int hgt, float f, int color) {
        g.fill(x, y, x + w, y + hgt, 0xFF0A1822);
        g.fill(x, y, x + (int) (w * f), y + hgt, color);
    }

    private static void slot(GuiGraphics g, Font font, int x, int y, String label, HardpointType t, int fireCd, int skillCd, int w) {
        g.drawString(font, label, x, y, 0xFF7FE0FF, true);
        if (t == null) { g.drawString(font, "-", x + 12, y, 0xFF556677, true); return; }
        g.drawString(font, Component.translatable("item.cyberarms." + t.id), x + 12, y, 0xFFFFFFFF, true);
        int bx = x + w - 34;
        if (t != HardpointType.JETPACK) bar(g, bx, y + 1, 16, 4, 1f - fireCd / (float) Math.max(1, t.cooldown), 0xFF27B5FF);
        bar(g, bx + 18, y + 1, 16, 4, 1f - skillCd / (float) Math.max(1, t.skillCooldown), 0xFFFFC040);
    }
}
