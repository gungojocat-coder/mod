package com.cyberarms.client;

import com.cyberarms.CyberArms;
import com.cyberarms.data.CyberData;
import com.cyberarms.data.HardpointType;
import com.cyberarms.item.CoreItem;
import com.cyberarms.net.Action;
import com.cyberarms.net.Net;
import com.cyberarms.registry.ModEntities;
import com.cyberarms.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class ClientEvents {
    private ClientEvents() {}

    // =========================================================================== mod bus
    @Mod.EventBusSubscriber(modid = CyberArms.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) { for (var k : Keys.all()) e.register(k); }

        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(ModEntities.SUPPORT_POD.get(), PodRenderer::new);
        }

        @SubscribeEvent
        public static void layers(EntityRenderersEvent.AddLayers e) {
            for (String skin : e.getSkins()) {
                PlayerRenderer r = e.getSkin(skin);
                if (r != null) r.addLayer(new PlayerGearLayer(r));
            }
        }

        @SubscribeEvent
        public static void overlays(RegisterGuiOverlaysEvent e) {
            e.registerAboveAll("cyberarms_hud", Hud::render);
        }

        @SubscribeEvent
        public static void itemColors(RegisterColorHandlersEvent.Item e) {
            // layer1 of the core icon is the glowing gem; tint it with the core color
            e.register((stack, tint) -> tint == 1 ? 0xFF000000 | CoreItem.rgb(CoreItem.getColor(stack)) : 0xFFFFFFFF,
                    ModItems.POWER_CORE.get());
        }
    }

    // =========================================================================== forge bus
    @Mod.EventBusSubscriber(modid = CyberArms.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class ForgeBus {

        @SubscribeEvent
        public static void logout(ClientPlayerNetworkEvent.LoggingOut e) { ClientGear.clear(); }

        /** Raise the arm while a cannon is firing. */
        @SubscribeEvent
        public static void pre(RenderLivingEvent.Pre<?, ?> e) {
            if (!(e.getEntity() instanceof AbstractClientPlayer p)) return;
            if (!(e.getRenderer().getModel() instanceof PlayerModel<?> m)) return;
            ClientGear.PlayerGear g = ClientGear.get(p.getId());
            if (g == null || g.aimTicks <= 0) return;
            if (g.aimSlot == 1) m.rightArmPose = HumanoidModel.ArmPose.BOW_AND_ARROW;
            else m.leftArmPose = HumanoidModel.ArmPose.BOW_AND_ARROW;
        }

        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            ClientGear.tick();
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null) return;
            ClientGear.PlayerGear g = ClientGear.get(p.getId());
            if (g == null || !g.data.hasCore) return;
            CyberData d = g.data;

            if (mc.screen == null) {
                if (Keys.FIRE_L.isDown() && d.left != null && d.cooldowns[CyberData.CD_FIRE_L] <= 0) Net.sendAction(Action.FIRE_L);
                if (Keys.FIRE_R.isDown() && d.right != null && d.cooldowns[CyberData.CD_FIRE_R] <= 0) Net.sendAction(Action.FIRE_R);
                while (Keys.SKILL_L.consumeClick()) Net.sendAction(Action.SKILL_L);
                while (Keys.SKILL_R.consumeClick()) Net.sendAction(Action.SKILL_R);
                while (Keys.SKILL_B.consumeClick()) Net.sendAction(Action.SKILL_B);
                while (Keys.SUPPORT.consumeClick()) Net.sendAction(Action.SUPPORT);
                while (Keys.UNEQUIP.consumeClick())
                    Net.sendAction(p.isShiftKeyDown() ? Action.UNEQUIP_ALL : Action.UNEQUIP_WEAPONS);
            }

            jetpack(mc, p, d);
        }

        /** Hold jump in the air to fly with the blue-flame jetpack. */
        private static void jetpack(Minecraft mc, LocalPlayer p, CyberData d) {
            if (d.back != HardpointType.JETPACK || d.overheated() || d.energy < 3f) return;
            if (!mc.options.keyJump.isDown() || mc.screen != null) return;
            if (p.onGround() || p.getAbilities().flying || p.isInWater() || p.isFallFlying()) return;

            boolean od = d.overdrive();
            Vec3 m = p.getDeltaMovement();
            double vy = Math.min(m.y + (od ? 0.20 : 0.13), od ? 0.80 : 0.58);

            Vec3 look = p.getLookAngle();
            Vec3 f = new Vec3(look.x, 0, look.z);
            f = f.lengthSqr() < 1e-4 ? Vec3.ZERO : f.normalize();
            Vec3 right = new Vec3(-f.z, 0, f.x);
            Vec3 acc = f.scale(p.input.forwardImpulse).add(right.scale(-p.input.leftImpulse)).scale(od ? 0.07 : 0.045);
            double vx = m.x + acc.x, vz = m.z + acc.z;
            double max = od ? 1.1 : 0.8;
            double h = Math.sqrt(vx * vx + vz * vz);
            if (h > max) { vx *= max / h; vz *= max / h; }

            p.setDeltaMovement(vx, vy, vz);
            p.fallDistance = 0;
            Net.sendAction(Action.THRUST);
        }
    }
}
