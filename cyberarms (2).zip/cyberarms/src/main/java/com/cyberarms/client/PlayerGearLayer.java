package com.cyberarms.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;

/**
 * Draws the core, arm weapons and jetpack on the player.
 *
 * Frame notes: LivingEntityRenderer flips x/y (scale -1,-1,1). We undo that after moving to the
 * body part, so GeckoLib models (y up, front = -z, right side of the player = +x) are authored
 * relative to the part pivot: arm pivot = shoulder, body pivot = top-center of torso.
 * If something looks off after the first in-game test, tweak the OFFSET_* constants below.
 */
public class PlayerGearLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    // fine tuning (in blocks) applied in the part's own frame
    private static final float[] OFFSET_ARM = {0f, 0f, 0f};
    private static final float[] OFFSET_BACK = {0f, 0f, 0f};
    private static final float[] OFFSET_CORE = {0f, 0f, 0f};

    public PlayerGearLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        ClientGear.PlayerGear g = ClientGear.get(p.getId());
        if (g == null || !g.data.hasCore || p.isInvisible()) return;
        PlayerModel<AbstractClientPlayer> m = getParentModel();

        // --- core on the chest (always fullbright, tinted with the chosen color)
        ps.pushPose();
        m.body.translateAndRotate(ps);
        ps.scale(-1f, -1f, 1f);
        ps.translate(OFFSET_CORE[0], OFFSET_CORE[1], OFFSET_CORE[2]);
        GearRenderer.of("core").render(ps, g.core, buf, null, null, LightTexture.FULL_BRIGHT);
        ps.popPose();

        // --- arms (left one is mirrored)
        if (g.right != null) renderArm(ps, buf, light, m.rightArm, g.right, false);
        if (g.left != null) renderArm(ps, buf, light, m.leftArm, g.left, true);

        // --- back
        if (g.back != null) {
            ps.pushPose();
            m.body.translateAndRotate(ps);
            ps.scale(-1f, -1f, 1f);
            ps.translate(OFFSET_BACK[0], OFFSET_BACK[1], OFFSET_BACK[2]);
            GearRenderer.of(g.back.id).render(ps, g.back, buf, null, null, light);
            ps.popPose();
        }
    }

    private void renderArm(PoseStack ps, MultiBufferSource buf, int light, net.minecraft.client.model.geom.ModelPart arm,
                           GearAnimatable a, boolean mirror) {
        ps.pushPose();
        arm.translateAndRotate(ps);
        ps.scale(-1f, -1f, 1f);
        if (mirror) ps.scale(-1f, 1f, 1f);
        ps.translate(OFFSET_ARM[0], OFFSET_ARM[1], OFFSET_ARM[2]);
        GearRenderer.of(a.id).render(ps, a, buf, null, null, light);
        ps.popPose();
    }
}
