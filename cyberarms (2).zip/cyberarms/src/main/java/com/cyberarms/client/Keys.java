package com.cyberarms.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

public final class Keys {
    private static final String CAT = "key.categories.cyberarms";

    public static final KeyMapping FIRE_L  = make("fire_left",   GLFW.GLFW_KEY_V);
    public static final KeyMapping FIRE_R  = make("fire_right",  GLFW.GLFW_KEY_B);
    public static final KeyMapping SKILL_L = make("skill_left",  GLFW.GLFW_KEY_G);
    public static final KeyMapping SKILL_R = make("skill_right", GLFW.GLFW_KEY_H);
    public static final KeyMapping SKILL_B = make("skill_back",  GLFW.GLFW_KEY_J);
    public static final KeyMapping SUPPORT = make("support",     GLFW.GLFW_KEY_K);
    public static final KeyMapping UNEQUIP = make("unequip",     GLFW.GLFW_KEY_U);

    private Keys() {}

    private static KeyMapping make(String name, int key) {
        return new KeyMapping("key.cyberarms." + name, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, key, CAT);
    }

    public static KeyMapping[] all() { return new KeyMapping[]{FIRE_L, FIRE_R, SKILL_L, SKILL_R, SKILL_B, SUPPORT, UNEQUIP}; }
}
