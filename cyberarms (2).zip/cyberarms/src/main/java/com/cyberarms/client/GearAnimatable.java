package com.cyberarms.client;

import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.util.RenderUtils;

/**
 * One animatable per equipped piece (core, blue cannon, ...) per player. It is not an entity,
 * the PlayerGearLayer renders it. Animations are triggered by name through {@link #trigger}.
 * Animation keys in the .animation.json files are "animation.<id>.<name>".
 */
public class GearAnimatable implements GeoAnimatable {
    public final String id;
    /** ARGB multiplier (used by the core to show its color). */
    public int tint = 0xFFFFFFFF;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private String pending;

    public GearAnimatable(String id) { this.id = id; }

    public void trigger(String anim) { this.pending = anim; }

    private String key(String name) { return "animation." + id + "." + name; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 2, state -> {
            AnimationController<GearAnimatable> c = state.getController();
            if (pending != null) {
                c.setAnimation(RawAnimation.begin()
                        .then(key(pending), Animation.LoopType.PLAY_ONCE)
                        .thenLoop(key("idle")));
                c.forceAnimationReset();
                pending = null;
            } else if (c.getCurrentRawAnimation() == null) {
                c.setAnimation(RawAnimation.begin().thenLoop(key("idle")));
            }
            return PlayState.CONTINUE;
        }));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override public double getTick(Object object) { return RenderUtils.getCurrentTick(); }
}
