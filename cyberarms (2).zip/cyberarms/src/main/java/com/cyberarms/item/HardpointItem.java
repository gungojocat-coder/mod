package com.cyberarms.item;

import com.cyberarms.data.CyberCaps;
import com.cyberarms.data.CyberData;
import com.cyberarms.data.HardpointType;
import com.cyberarms.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** A weapon/module. Use = attach to the player's core (if there is room and load allows). */
public class HardpointItem extends Item {
    public final HardpointType type;

    public HardpointItem(HardpointType type, Properties props) {
        super(props.stacksTo(1));
        this.type = type;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);

        CyberData d = CyberCaps.get(player);
        String why = d.whyCannotEquip(type);
        if (why != null) {
            player.displayClientMessage(Component.translatable(why, d.currentLoad(), CyberData.MAX_LOAD, type.weight)
                    .withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }
        d.equip(type);
        stack.shrink(1);
        if (player instanceof ServerPlayer sp) {
            Net.sync(sp);
            int slot = d.back == type ? 2 : (d.right == type ? 1 : 0);
            Net.anim(sp, slot, "equip");
        }
        player.displayClientMessage(Component.translatable("message.cyberarms.equipped",
                Component.translatable("item.cyberarms." + type.id), d.currentLoad(), CyberData.MAX_LOAD), true);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack s, @Nullable Level lvl, List<Component> tip, TooltipFlag f) {
        tip.add(Component.translatable("tooltip.cyberarms." + type.id).withStyle(ChatFormatting.AQUA));
        tip.add(Component.translatable("tooltip.cyberarms.weight", type.weight).withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable(type.mount == HardpointType.Mount.ARM
                ? "tooltip.cyberarms.mount_arm" : "tooltip.cyberarms.mount_back").withStyle(ChatFormatting.DARK_GRAY));
    }
}
