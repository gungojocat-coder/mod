package com.cyberarms.item;

import com.cyberarms.data.CyberCaps;
import com.cyberarms.data.CyberData;
import com.cyberarms.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * The central power core. Must be worn before any weapon can be attached.
 * Use = wear it. Dye in the other hand = recolor. Sneak + use (no dye) = cycle color.
 */
public class CoreItem extends Item {
    public static final String TAG_COLOR = "CoreColor";

    public CoreItem(Properties props) { super(props.stacksTo(1)); }

    public static int getColor(ItemStack s) {
        CompoundTag t = s.getTag();
        return t != null && t.contains(TAG_COLOR) ? t.getInt(TAG_COLOR) & 15 : 3;
    }

    public static void setColor(ItemStack s, int dyeId) { s.getOrCreateTag().putInt(TAG_COLOR, dyeId & 15); }

    public static int rgb(int dyeId) { return DyeColor.byId(dyeId & 15).getFireworkColor(); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);

        ItemStack other = player.getItemInHand(hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        if (other.getItem() instanceof DyeItem dye) {
            setColor(stack, dye.getDyeColor().getId());
            if (!player.getAbilities().instabuild) other.shrink(1);
            player.displayClientMessage(Component.translatable("message.cyberarms.core_recolored",
                    Component.translatable("color.minecraft." + dye.getDyeColor().getName())), true);
            return InteractionResultHolder.consume(stack);
        }
        if (player.isShiftKeyDown()) {
            setColor(stack, getColor(stack) + 1);
            player.displayClientMessage(Component.translatable("message.cyberarms.core_recolored",
                    Component.translatable("color.minecraft." + DyeColor.byId(getColor(stack)).getName())), true);
            return InteractionResultHolder.consume(stack);
        }

        CyberData d = CyberCaps.get(player);
        if (d.hasCore) {
            player.displayClientMessage(Component.translatable("message.cyberarms.core_already"), true);
            return InteractionResultHolder.fail(stack);
        }
        d.hasCore = true;
        d.coreColor = getColor(stack);
        d.energy = CyberData.MAX_ENERGY;
        stack.shrink(1);
        if (player instanceof ServerPlayer sp) {
            Net.sync(sp);
            Net.anim(sp, 3, "equip");
        }
        player.displayClientMessage(Component.translatable("message.cyberarms.core_online"), true);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack s, @Nullable Level lvl, List<Component> tip, TooltipFlag f) {
        tip.add(Component.translatable("tooltip.cyberarms.core.1").withStyle(ChatFormatting.AQUA));
        tip.add(Component.translatable("tooltip.cyberarms.core.2", CyberData.MAX_LOAD).withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("tooltip.cyberarms.core.3").withStyle(ChatFormatting.DARK_GRAY));
        tip.add(Component.translatable("tooltip.cyberarms.core.color",
                Component.translatable("color.minecraft." + DyeColor.byId(getColor(s)).getName())).withStyle(ChatFormatting.GRAY));
    }
}
