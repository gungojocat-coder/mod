package com.cyberarms.data;

/**
 * All attachable weapons / modules. Numbers are the single place to balance the mod.
 * weight  = how much of the Core's max load it uses
 * cost    = energy per primary action, skillCost = energy per skill
 */
public enum HardpointType {
    //            id             mount        weight cost skillCost dmg   range  cd  skillCd
    BLUE_CANNON("blue_cannon", Mount.ARM,   30,  18,  60,  8.0f,  48.0, 8,  100),
    RED_CANNON ("red_cannon",  Mount.ARM,   45,  55, 180, 18.0f,  64.0, 26, 240),
    ARM_BLADE  ("arm_blade",   Mount.ARM,   20,   8,  50, 12.0f,   3.6, 12,  80),
    JETPACK    ("jetpack",     Mount.BACK,  35,   0,  70,  6.0f,   0.0, 0,  120);

    public enum Mount { ARM, BACK }

    public final String id;
    public final Mount mount;
    public final int weight;
    public final int cost;
    public final int skillCost;
    public final float damage;
    public final double range;
    public final int cooldown;
    public final int skillCooldown;

    HardpointType(String id, Mount mount, int weight, int cost, int skillCost,
                  float damage, double range, int cooldown, int skillCooldown) {
        this.id = id;
        this.mount = mount;
        this.weight = weight;
        this.cost = cost;
        this.skillCost = skillCost;
        this.damage = damage;
        this.range = range;
        this.cooldown = cooldown;
        this.skillCooldown = skillCooldown;
    }

    public static HardpointType byId(String id) {
        for (HardpointType t : values()) if (t.id.equals(id)) return t;
        return null;
    }

    public boolean isCannon() { return this == BLUE_CANNON || this == RED_CANNON; }
}
