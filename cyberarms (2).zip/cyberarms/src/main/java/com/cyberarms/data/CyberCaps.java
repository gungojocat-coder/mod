package com.cyberarms.data;

import com.cyberarms.CyberArms;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;

public final class CyberCaps {
    public static final Capability<CyberData> CYBER = CapabilityManager.get(new CapabilityToken<>() {});
    public static final ResourceLocation KEY = new ResourceLocation(CyberArms.MODID, "cyber_data");

    private CyberCaps() {}

    /** Never returns null; a detached default is returned if the capability is missing. */
    public static CyberData get(Player p) {
        return p.getCapability(CYBER).orElseGet(CyberData::new);
    }

    public static class Provider implements ICapabilitySerializable<CompoundTag> {
        private final CyberData data = new CyberData();
        private final LazyOptional<CyberData> opt = LazyOptional.of(() -> data);

        @Override
        public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, Direction side) {
            return cap == CYBER ? opt.cast() : LazyOptional.empty();
        }

        @Override public CompoundTag serializeNBT() { return data.serializeNBT(); }
        @Override public void deserializeNBT(CompoundTag nbt) { data.deserializeNBT(nbt); }
    }
}
