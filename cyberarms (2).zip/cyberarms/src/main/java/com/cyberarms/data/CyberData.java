package com.cyberarms.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.util.INBTSerializable;

/** Per-player state: core, equipped hardpoints, energy, overdrive, cooldowns. */
public class CyberData implements INBTSerializable<CompoundTag> {
    public static final int MAX_LOAD = 100;          // max load the core can carry
    public static final float MAX_ENERGY = 1000f;
    public static final int OVERDRIVE_TICKS = 20 * 30;
    public static final int OVERHEAT_TICKS = 20 * 6;
    public static final int SUPPORT_COOLDOWN = 20 * 60;

    // cooldown slots
    public static final int CD_FIRE_L = 0, CD_FIRE_R = 1, CD_SKILL_L = 2, CD_SKILL_R = 3, CD_SKILL_B = 4;

    public boolean hasCore;
    public int coreColor = 3;               // DyeColor id (3 = light blue)
    public float energy = MAX_ENERGY;
    public HardpointType left, right, back;
    public int overdriveTicks;
    public int overheatTicks;
    public int supportCooldown;
    public final int[] cooldowns = new int[5];

    public boolean overdrive() { return overdriveTicks > 0; }
    public boolean overheated() { return overheatTicks > 0; }

    public int currentLoad() {
        int w = 0;
        if (left != null) w += left.weight;
        if (right != null) w += right.weight;
        if (back != null) w += back.weight;
        return w;
    }

    public boolean has(HardpointType t) { return left == t || right == t || back == t; }

    /** @return null if ok, otherwise a lang key explaining why not. */
    public String whyCannotEquip(HardpointType t) {
        if (!hasCore) return "message.cyberarms.need_core";
        if (t.mount == HardpointType.Mount.BACK) {
            if (back != null) return "message.cyberarms.slot_full";
        } else if (left != null && right != null) {
            return "message.cyberarms.slot_full";
        }
        if (currentLoad() + t.weight > MAX_LOAD) return "message.cyberarms.over_load";
        return null;
    }

    /** Equips into the first free slot (right arm first). Call whyCannotEquip first. */
    public void equip(HardpointType t) {
        if (t.mount == HardpointType.Mount.BACK) back = t;
        else if (right == null) right = t;
        else left = t;
    }

    public void clearWeapons() { left = right = back = null; }

    public float energyCost(float base) { return overdrive() ? base * 0.5f : base; }
    public int cooldownTime(int base) { return overdrive() ? Math.max(1, base / 2) : base; }
    public float damageMul() { return overdrive() ? 1.75f : 1f; }

    public void copyFrom(CyberData o) { deserializeNBT(o.serializeNBT()); }

    private static String name(HardpointType t) { return t == null ? "" : t.id; }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag t = new CompoundTag();
        t.putBoolean("core", hasCore);
        t.putInt("color", coreColor);
        t.putFloat("energy", energy);
        t.putString("left", name(left));
        t.putString("right", name(right));
        t.putString("back", name(back));
        t.putInt("od", overdriveTicks);
        t.putInt("oh", overheatTicks);
        t.putInt("sup", supportCooldown);
        t.putIntArray("cd", cooldowns);
        return t;
    }

    @Override
    public void deserializeNBT(CompoundTag t) {
        hasCore = t.getBoolean("core");
        coreColor = t.getInt("color");
        energy = t.getFloat("energy");
        left = HardpointType.byId(t.getString("left"));
        right = HardpointType.byId(t.getString("right"));
        back = HardpointType.byId(t.getString("back"));
        overdriveTicks = t.getInt("od");
        overheatTicks = t.getInt("oh");
        supportCooldown = t.getInt("sup");
        int[] cd = t.getIntArray("cd");
        for (int i = 0; i < cooldowns.length; i++) cooldowns[i] = i < cd.length ? cd[i] : 0;
    }
}
