package com.cyberarms.registry;

import com.cyberarms.CyberArms;
import com.cyberarms.data.HardpointType;
import com.cyberarms.item.CoreItem;
import com.cyberarms.item.HardpointItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, CyberArms.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CyberArms.MODID);

    public static final RegistryObject<Item> POWER_CORE = ITEMS.register("power_core",
            () -> new CoreItem(new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> BLUE_CANNON = ITEMS.register("blue_cannon",
            () -> new HardpointItem(HardpointType.BLUE_CANNON, new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> RED_CANNON = ITEMS.register("red_cannon",
            () -> new HardpointItem(HardpointType.RED_CANNON, new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> ARM_BLADE = ITEMS.register("arm_blade",
            () -> new HardpointItem(HardpointType.ARM_BLADE, new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> JETPACK = ITEMS.register("jetpack",
            () -> new HardpointItem(HardpointType.JETPACK, new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cyberarms"))
                    .icon(() -> new ItemStack(POWER_CORE.get()))
                    .displayItems((params, out) -> {
                        out.accept(POWER_CORE.get());
                        out.accept(BLUE_CANNON.get());
                        out.accept(RED_CANNON.get());
                        out.accept(ARM_BLADE.get());
                        out.accept(JETPACK.get());
                    })
                    .build());

    private ModItems() {}
}
