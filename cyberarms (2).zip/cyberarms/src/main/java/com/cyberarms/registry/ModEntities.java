package com.cyberarms.registry;

import com.cyberarms.CyberArms;
import com.cyberarms.entity.SupportPodEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CyberArms.MODID);

    public static final RegistryObject<EntityType<SupportPodEntity>> SUPPORT_POD = ENTITIES.register("support_pod",
            () -> EntityType.Builder.<SupportPodEntity>of(SupportPodEntity::new, MobCategory.MISC)
                    .sized(2.0f, 2.6f)
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .fireImmune()
                    .build("support_pod"));

    private ModEntities() {}
}
