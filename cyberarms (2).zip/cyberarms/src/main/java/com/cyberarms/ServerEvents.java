package com.cyberarms;

import com.cyberarms.data.CyberCaps;
import com.cyberarms.data.CyberData;
import com.cyberarms.logic.Actions;
import com.cyberarms.logic.Fx;
import com.cyberarms.logic.Sched;
import com.cyberarms.net.Net;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CyberArms.MODID)
public final class ServerEvents {
    private ServerEvents() {}

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> e) {
        if (e.getObject() instanceof Player) e.addCapability(CyberCaps.KEY, new CyberCaps.Provider());
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        e.getOriginal().reviveCaps();
        CyberData from = CyberCaps.get(e.getOriginal());
        CyberData to = CyberCaps.get(e.getEntity());
        to.copyFrom(from);
        if (e.isWasDeath()) {                 // gear survives death, short-lived state does not
            to.overdriveTicks = 0;
            to.overheatTicks = 0;
            to.energy = CyberData.MAX_ENERGY;
            java.util.Arrays.fill(to.cooldowns, 0);
        }
        e.getOriginal().invalidateCaps();
    }

    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent e) { if (e.getEntity() instanceof ServerPlayer p) Net.sync(p); }
    @SubscribeEvent public static void respawn(PlayerEvent.PlayerRespawnEvent e) { if (e.getEntity() instanceof ServerPlayer p) Net.sync(p); }
    @SubscribeEvent public static void dim(PlayerEvent.PlayerChangedDimensionEvent e) { if (e.getEntity() instanceof ServerPlayer p) Net.sync(p); }

    @SubscribeEvent
    public static void logout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) Actions.restoreFlight(p);
    }

    /** When a player starts tracking another player, send that player's gear so it renders. */
    @SubscribeEvent
    public static void startTracking(PlayerEvent.StartTracking e) {
        if (e.getTarget() instanceof ServerPlayer owner && e.getEntity() instanceof ServerPlayer viewer) Net.syncTo(viewer, owner);
    }

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) Sched.tick();
    }

    @SubscribeEvent public static void stopped(ServerStoppedEvent e) { Sched.clear(); }

    /** Overdrive: -20% damage taken. */
    @SubscribeEvent
    public static void hurt(LivingHurtEvent e) {
        if (e.getEntity() instanceof Player p && CyberCaps.get(p).overdrive()) e.setAmount(e.getAmount() * 0.8f);
    }

    @SubscribeEvent
    public static void playerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        Actions.jetCleanup(p);
        CyberData d = CyberCaps.get(p);
        if (!d.hasCore) return;

        for (int i = 0; i < d.cooldowns.length; i++) if (d.cooldowns[i] > 0) d.cooldowns[i]--;
        if (d.supportCooldown > 0) d.supportCooldown--;

        if (d.overdriveTicks > 0) {
            d.overdriveTicks--;
            d.energy = Math.min(CyberData.MAX_ENERGY, d.energy + 1.0f);
            if (p.tickCount % 10 == 0) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 30, 0, false, false, false));
                ServerLevel l = (ServerLevel) p.level();
                l.sendParticles(new DustParticleOptions(Fx.BLUE, 1.0f), p.getX(), p.getY() + 1, p.getZ(), 10, 0.5, 0.8, 0.5, 0.02);
            }
            if (d.overdriveTicks == 0) {      // overdrive ends -> overheat
                d.overheatTicks = CyberData.OVERHEAT_TICKS;
                d.energy = Math.min(d.energy, CyberData.MAX_ENERGY * 0.2f);
                p.displayClientMessage(Component.translatable("message.cyberarms.overdrive_off"), true);
                Fx.sound((ServerLevel) p.level(), p.position(), SoundEvents.FIRE_EXTINGUISH, 1.5f, 0.6f);
            }
        } else if (d.overheatTicks > 0) {
            d.overheatTicks--;
            if (p.tickCount % 10 == 0) p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 0, false, false, false));
        } else {
            d.energy = Math.min(CyberData.MAX_ENERGY, d.energy + 0.35f);
        }

        if (p.tickCount % 5 == 0) Net.sync(p);
    }
}
