package com.cyberarms;

import com.cyberarms.data.CyberData;
import com.cyberarms.net.Net;
import com.cyberarms.registry.ModEntities;
import com.cyberarms.registry.ModItems;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CyberArms.MODID)
public class CyberArms {
    public static final String MODID = "cyberarms";

    public CyberArms() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
        ModEntities.ENTITIES.register(bus);
        bus.addListener(this::commonSetup);
        bus.addListener(this::registerCaps);
    }

    private void commonSetup(FMLCommonSetupEvent e) { e.enqueueWork(Net::init); }

    private void registerCaps(RegisterCapabilitiesEvent e) { e.register(CyberData.class); }
}
