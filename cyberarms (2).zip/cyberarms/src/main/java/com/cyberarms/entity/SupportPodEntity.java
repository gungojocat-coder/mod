package com.cyberarms.entity;

import com.cyberarms.data.CyberCaps;
import com.cyberarms.data.CyberData;
import com.cyberarms.net.Net;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import org.joml.Vector3f;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Support drop pod. Phases: SIGNAL (beacon column) -> FALL (from the sky) -> OPEN (charges cores
 * in range and grants Overdrive) -> CLOSE (folds up and leaves).
 */
public class SupportPodEntity extends Entity implements GeoEntity {
    public static final int SIGNAL = 0, FALL = 1, OPEN = 2, CLOSE = 3;
    private static final int SIGNAL_TICKS = 60, OPEN_TICKS = 200, CLOSE_TICKS = 30;
    private static final double CHARGE_RADIUS = 4.5;

    private static final EntityDataAccessor<Integer> PHASE =
            SynchedEntityData.defineId(SupportPodEntity.class, EntityDataSerializers.INT);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final Set<UUID> boosted = new HashSet<>();
    private int timer;
    private double groundY;
    private UUID owner;

    public SupportPodEntity(EntityType<? extends SupportPodEntity> type, Level level) {
        super(type, level);
        this.noCulling = true;
    }

    public void setOwner(UUID id) { this.owner = id; }
    public int getPhase() { return this.entityData.get(PHASE); }
    private void setPhase(int p) { this.entityData.set(PHASE, p); timer = 0; }

    public void initAt(double x, double y, double z) {
        this.groundY = y;
        setPos(x, y, z);
    }

    // ---------------------------------------------------------------------- tick

    @Override
    public void tick() {
        super.tick();
        int phase = getPhase();
        if (level().isClientSide) { clientFx(phase); return; }

        ServerLevel sl = (ServerLevel) level();
        timer++;
        switch (phase) {
            case SIGNAL -> {
                if (timer % 2 == 0) {
                    for (double h = 0; h < 40; h += 1.5) {
                        sl.sendParticles(new DustParticleOptions(new Vector3f(1f, 0.15f, 0.15f), 1.6f),
                                getX(), groundY + h, getZ(), 1, 0.08, 0, 0.08, 0);
                    }
                }
                if (timer == 1) sl.playSound(null, getX(), getY(), getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 2f, 1.4f);
                if (timer >= SIGNAL_TICKS) {
                    setPos(getX(), groundY + 55, getZ());
                    setPhase(FALL);
                    sl.playSound(null, getX(), groundY, getZ(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 3f, 0.5f);
                }
            }
            case FALL -> {
                setDeltaMovement(0, -1.6, 0);
                move(MoverType.SELF, getDeltaMovement());
                sl.sendParticles(ParticleTypes.FLAME, getX(), getY() + 2.6, getZ(), 6, 0.3, 0.2, 0.3, 0.02);
                if (onGround() || getY() <= groundY + 0.05) land(sl);
                else if (getY() < level().getMinBuildHeight()) discard();
            }
            case OPEN -> openTick(sl);
            case CLOSE -> { if (timer >= CLOSE_TICKS) discard(); }
            default -> discard();
        }
    }

    private void land(ServerLevel sl) {
        setPos(getX(), Math.max(getY(), groundY), getZ());
        setDeltaMovement(Vec3.ZERO);
        setPhase(OPEN);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 2.5f, 0.7f);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 2.5f, 0.6f);
        sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 0.5, getZ(), 1, 0, 0, 0, 0);
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 1, getZ(), 60, 1.5, 0.5, 1.5, 0.4);
        // impact shockwave: hurts monsters/animals, never players
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(3.5, 1.5, 3.5))) {
            if (!(e instanceof Player)) e.hurt(damageSources().explosion(null, null), 14f);
        }
    }

    private void openTick(ServerLevel sl) {
        if (timer % 4 == 0) {
            for (int i = 0; i < 24; i++) {
                double a = i * Math.PI * 2 / 24;
                sl.sendParticles(new DustParticleOptions(new Vector3f(0.2f, 0.7f, 1f), 1.2f),
                        getX() + Math.cos(a) * CHARGE_RADIUS, getY() + 0.2, getZ() + Math.sin(a) * CHARGE_RADIUS, 1, 0, 0, 0, 0);
            }
        }
        AABB box = new AABB(getX() - CHARGE_RADIUS, getY() - 2, getZ() - CHARGE_RADIUS,
                getX() + CHARGE_RADIUS, getY() + 4, getZ() + CHARGE_RADIUS);
        for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, box)) {
            CyberData d = CyberCaps.get(p);
            if (!d.hasCore || p.distanceToSqr(this) > CHARGE_RADIUS * CHARGE_RADIUS) continue;
            boolean changed = false;
            if (d.energy < CyberData.MAX_ENERGY) {
                d.energy = Math.min(CyberData.MAX_ENERGY, d.energy + 30f);
                changed = true;
            }
            if (d.energy >= CyberData.MAX_ENERGY && boosted.add(p.getUUID())) {
                d.overdriveTicks = CyberData.OVERDRIVE_TICKS;
                d.overheatTicks = 0;
                p.displayClientMessage(Component.translatable("message.cyberarms.overdrive_on"), true);
                sl.playSound(null, p.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 2f, 1.2f);
                changed = true;
                Net.anim(p, 3, "overdrive");
            }
            if (changed && (timer % 4 == 0 || boosted.contains(p.getUUID()))) Net.sync(p);
        }
        if (timer >= OPEN_TICKS) {
            setPhase(CLOSE);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.PISTON_CONTRACT, SoundSource.PLAYERS, 2f, 0.6f);
        }
    }

    private void clientFx(int phase) {
        if (phase == FALL) {
            level().addParticle(ParticleTypes.FLAME, getX(), getY() + 2.6, getZ(), 0, 0.4, 0);
            level().addParticle(ParticleTypes.LARGE_SMOKE, getX(), getY() + 3, getZ(), 0, 0.2, 0);
        } else if (phase == OPEN && tickCount % 3 == 0) {
            level().addParticle(ParticleTypes.ELECTRIC_SPARK,
                    getX() + (random.nextDouble() - 0.5) * 2, getY() + 1 + random.nextDouble() * 1.5,
                    getZ() + (random.nextDouble() - 0.5) * 2, 0, 0.1, 0);
        }
    }

    // ---------------------------------------------------------------------- entity plumbing

    @Override protected void defineSynchedData() { this.entityData.define(PHASE, SIGNAL); }

    @Override
    protected void readAdditionalSaveData(CompoundTag t) {
        groundY = t.getDouble("groundY");
        if (t.hasUUID("owner")) owner = t.getUUID("owner");
        this.entityData.set(PHASE, t.getInt("phase"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag t) {
        t.putDouble("groundY", groundY);
        if (owner != null) t.putUUID("owner", owner);
        t.putInt("phase", getPhase());
    }

    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushedByFluid() { return false; }
    @Override public boolean hurt(DamageSource s, float a) { return false; }
    @Override public boolean isNoGravity() { return true; }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    // ---------------------------------------------------------------------- GeckoLib

    private static String a(String n) { return "animation.support_pod." + n; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, state -> {
            switch (getPhase()) {
                case FALL -> state.setAndContinue(RawAnimation.begin().thenLoop(a("fall")));
                case OPEN -> state.setAndContinue(RawAnimation.begin()
                        .then(a("open"), Animation.LoopType.PLAY_ONCE).thenLoop(a("charge")));
                case CLOSE -> state.setAndContinue(RawAnimation.begin().then(a("close"), Animation.LoopType.PLAY_ONCE));
                default -> state.setAndContinue(RawAnimation.begin().thenLoop(a("fall")));
            }
            return PlayState.CONTINUE;
        }));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
