package com.cyberarms.net;

import com.cyberarms.CyberArms;
import com.cyberarms.client.ClientHooks;
import com.cyberarms.data.CyberCaps;
import com.cyberarms.logic.Actions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class Net {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CyberArms.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Net() {}

    public static void init() {
        int id = 0;

        // client -> server : an action key was pressed
        CHANNEL.registerMessage(id++, ActionMsg.class,
                (m, b) -> b.writeVarInt(m.action.ordinal()),
                b -> new ActionMsg(Action.byOrdinal(b.readVarInt())),
                Net::handleAction);

        // server -> client : full state of one player (for HUD and rendering)
        CHANNEL.registerMessage(id++, SyncMsg.class,
                (m, b) -> { b.writeVarInt(m.entityId); b.writeNbt(m.tag); },
                b -> new SyncMsg(b.readVarInt(), b.readNbt()),
                (m, ctx) -> {
                    ctx.get().enqueueWork(() ->
                            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.onSync(m.entityId, m.tag)));
                    ctx.get().setPacketHandled(true);
                });

        // server -> client : play an animation on one hardpoint (0 = left, 1 = right, 2 = back)
        CHANNEL.registerMessage(id++, AnimMsg.class,
                (m, b) -> { b.writeVarInt(m.entityId); b.writeByte(m.slot); b.writeUtf(m.anim); },
                b -> new AnimMsg(b.readVarInt(), b.readByte(), b.readUtf()),
                (m, ctx) -> {
                    ctx.get().enqueueWork(() ->
                            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.onAnim(m.entityId, m.slot, m.anim)));
                    ctx.get().setPacketHandled(true);
                });
    }

    private static void handleAction(ActionMsg m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null && m.action != null) Actions.handle(p, m.action);
        });
        c.setPacketHandled(true);
    }

    // ---- helpers ---------------------------------------------------------------------------

    /** Send the player's data to the player and everyone tracking them. */
    public static void sync(ServerPlayer p) {
        CompoundTag tag = CyberCaps.get(p).serializeNBT();
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new SyncMsg(p.getId(), tag));
    }

    /** Send the player's data to a single player (used when they start tracking someone). */
    public static void syncTo(ServerPlayer target, ServerPlayer owner) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> target),
                new SyncMsg(owner.getId(), CyberCaps.get(owner).serializeNBT()));
    }

    public static void anim(ServerPlayer p, int slot, String anim) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new AnimMsg(p.getId(), slot, anim));
    }

    public static void sendAction(Action a) { CHANNEL.sendToServer(new ActionMsg(a)); }

    // ---- messages --------------------------------------------------------------------------

    public record ActionMsg(Action action) {}
    public record SyncMsg(int entityId, CompoundTag tag) {}
    public record AnimMsg(int entityId, int slot, String anim) {}
}
