package com.cyberarms.net;

/** Every client -> server request. */
public enum Action {
    FIRE_L, FIRE_R,
    SKILL_L, SKILL_R, SKILL_B,
    SUPPORT,
    UNEQUIP_WEAPONS, UNEQUIP_ALL,
    THRUST;

    public static Action byOrdinal(int i) {
        Action[] v = values();
        return i >= 0 && i < v.length ? v[i] : null;
    }
}
