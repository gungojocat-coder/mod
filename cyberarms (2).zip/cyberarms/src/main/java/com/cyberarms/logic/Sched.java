package com.cyberarms.logic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Tiny server-tick scheduler (charge-up delays etc). Call tick() once per server tick. */
public final class Sched {
    private record Task(int[] left, Runnable run) {}
    private static final List<Task> TASKS = new ArrayList<>();
    private static final List<Task> ADD = new ArrayList<>();

    private Sched() {}

    public static void later(int ticks, Runnable r) { ADD.add(new Task(new int[]{Math.max(1, ticks)}, r)); }

    public static void tick() {
        if (!ADD.isEmpty()) { TASKS.addAll(ADD); ADD.clear(); }
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            if (--t.left[0] <= 0) {
                it.remove();
                try { t.run.run(); } catch (Exception ignored) { }
            }
        }
    }

    public static void clear() { TASKS.clear(); ADD.clear(); }
}
