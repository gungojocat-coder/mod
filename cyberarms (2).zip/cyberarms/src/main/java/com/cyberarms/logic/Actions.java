package com.cyberarms.logic;

import com.cyberarms.data.CyberCaps;
import com.cyberarms.data.CyberData;
import com.cyberarms.data.HardpointType;
import com.cyberarms.entity.SupportPodEntity;
import com.cyberarms.item.CoreItem;
import com.cyberarms.net.Action;
import com.cyberarms.net.Net;
import com.cyberarms.registry.ModEntities;
import com.cyberarms.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** All server-side gameplay: firing, skills, jetpack, support call, unequip. */
public final class Actions {
    /** players who got server-side "mayfly" because of the jetpack (so the anti-fly kick does not trigger) */
    private static final Map<UUID, Integer> JET_FLAG = new HashMap<>();

    private Actions() {}

    // ============================================================================ dispatch

    public static void handle(ServerPlayer p, Action a) {
        CyberData d = CyberCaps.get(p);
        if (!d.hasCore) return;
        switch (a) {
            case FIRE_L -> primary(p, d, d.left, 0, CyberData.CD_FIRE_L);
            case FIRE_R -> primary(p, d, d.right, 1, CyberData.CD_FIRE_R);
            case SKILL_L -> skill(p, d, d.left, 0, CyberData.CD_SKILL_L);
            case SKILL_R -> skill(p, d, d.right, 1, CyberData.CD_SKILL_R);
            case SKILL_B -> skill(p, d, d.back, 2, CyberData.CD_SKILL_B);
            case THRUST -> thrust(p, d);
            case SUPPORT -> callSupport(p, d);
            case UNEQUIP_WEAPONS -> unequip(p, d, false);
            case UNEQUIP_ALL -> unequip(p, d, true);
        }
    }

    private static boolean blocked(ServerPlayer p, CyberData d) {
        if (d.overheated()) {
            p.displayClientMessage(Component.translatable("message.cyberarms.overheated").withStyle(ChatFormatting.RED), true);
            return true;
        }
        return false;
    }

    private static boolean pay(ServerPlayer p, CyberData d, float baseCost) {
        float c = d.energyCost(baseCost);
        if (d.energy < c) {
            p.displayClientMessage(Component.translatable("message.cyberarms.low_energy").withStyle(ChatFormatting.RED), true);
            return false;
        }
        d.energy -= c;
        return true;
    }

    // ============================================================================ primary fire

    private static void primary(ServerPlayer p, CyberData d, HardpointType t, int slot, int cd) {
        if (t == null || t == HardpointType.JETPACK || d.cooldowns[cd] > 0 || blocked(p, d)) return;
        if (!pay(p, d, t.cost)) return;
        d.cooldowns[cd] = d.cooldownTime(t.cooldown);
        Net.anim(p, slot, "fire");
        ServerLevel l = (ServerLevel) p.level();

        switch (t) {
            case BLUE_CANNON -> {
                Fx.sound(l, p.position(), SoundEvents.BEACON_DEACTIVATE, 1.6f, 1.8f);
                fireBeam(p, d, muzzle(p, slot), p.getLookAngle(), t.range, t.damage, false, 0.6, Fx.BLUE, 1.1f, 1.0f);
            }
            case RED_CANNON -> {
                Fx.sound(l, p.position(), SoundEvents.GENERIC_EXPLODE, 1.2f, 1.5f);
                Fx.sound(l, p.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.6f, 2.0f);
                fireBeam(p, d, muzzle(p, slot), p.getLookAngle(), t.range, t.damage, true, 1.0, Fx.RED, 1.7f, 2.4f);
            }
            case ARM_BLADE -> slash(p, d, t.damage, 3.6, 70, slot == 1 ? 1 : -1);
            default -> { }
        }
        Net.sync(p);
    }

    // ============================================================================ skills

    private static void skill(ServerPlayer p, CyberData d, HardpointType t, int slot, int cd) {
        if (t == null || d.cooldowns[cd] > 0 || blocked(p, d)) return;
        if (!pay(p, d, t.skillCost)) return;
        d.cooldowns[cd] = d.cooldownTime(t.skillCooldown);
        Net.anim(p, slot, "skill");
        ServerLevel l = (ServerLevel) p.level();
        Vec3 look = p.getLookAngle();

        switch (t) {
            case BLUE_CANNON -> {
                // Pulse Barrage: 5 rapid fans of 3 beams
                for (int volley = 0; volley < 5; volley++) {
                    final int v = volley;
                    Sched.later(volley * 3 + 1, () -> {
                        if (!p.isAlive()) return;
                        Vec3 dir = p.getLookAngle();
                        for (int k = -1; k <= 1; k++) {
                            Vec3 spread = rotateY(dir, Math.toRadians(k * 7.0));
                            fireBeam(p, d, muzzle(p, slot), spread, t.range, t.damage * 0.7f, false, 0.5, Fx.BLUE, 1.0f, 0.8f);
                        }
                        Fx.sound((ServerLevel) p.level(), p.position(), SoundEvents.BLAZE_SHOOT, 0.8f, 1.6f + v * 0.05f);
                    });
                }
            }
            case RED_CANNON -> {
                // Annihilation Beam: 0.8s charge, then a huge piercing beam
                Fx.sound(l, p.position(), SoundEvents.BEACON_POWER_SELECT, 2f, 0.5f);
                for (int i = 0; i < 16; i += 4) {
                    Sched.later(i + 1, () -> Fx.burst((ServerLevel) p.level(), muzzle(p, slot), Fx.RED, 12, 0.4));
                }
                Sched.later(16, () -> {
                    if (!p.isAlive()) return;
                    ServerLevel lv = (ServerLevel) p.level();
                    Fx.sound(lv, p.position(), SoundEvents.GENERIC_EXPLODE, 3f, 0.6f);
                    Fx.sound(lv, p.position(), SoundEvents.LIGHTNING_BOLT_IMPACT, 2f, 0.7f);
                    Vec3 end = fireBeam(p, d, muzzle(p, slot), p.getLookAngle(), 90, t.damage * 2.6f, true, 1.8, Fx.RED, 2.6f, 4.0f);
                    p.push(-p.getLookAngle().x * 0.6, 0.1, -p.getLookAngle().z * 0.6);
                    p.hurtMarked = true;
                    Net.sync(p);
                });
            }
            case ARM_BLADE -> {
                // Plasma Slash: dash forward and cut everything in a wide arc
                Vec3 dash = new Vec3(look.x, 0, look.z).normalize().scale(1.7).add(0, 0.12, 0);
                p.setDeltaMovement(dash);
                p.hurtMarked = true;
                Fx.sound(l, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.5f, 0.6f);
                Sched.later(3, () -> slash(p, d, t.damage * 1.7f, 5.5, 160, slot == 1 ? 1 : -1));
                Sched.later(7, () -> slash(p, d, t.damage * 1.7f, 5.5, 160, slot == 1 ? -1 : 1));
            }
            case JETPACK -> {
                // Afterburner: blue-flame launch forward, scorches whatever is behind
                Vec3 back = new Vec3(-look.x, 0, -look.z).normalize();
                for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(3.5), e -> e != p)) {
                    e.hurt(p.damageSources().playerAttack(p), t.damage * d.damageMul());
                    e.setSecondsOnFire(5);
                }
                p.setDeltaMovement(look.scale(2.3).add(0, 0.55, 0));
                p.hurtMarked = true;
                p.fallDistance = 0;
                Fx.sound(l, p.position(), SoundEvents.FIRECHARGE_USE, 2f, 0.5f);
                for (int i = 0; i < 12; i++) {
                    Vec3 o = p.position().add(back.scale(0.4 + i * 0.35)).add(0, 1.0, 0);
                    l.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, o.x, o.y, o.z, 6, 0.2, 0.2, 0.2, 0.05);
                }
            }
        }
        Net.sync(p);
    }

    // ============================================================================ beam / slash

    /** Right-hand / left-hand muzzle position (a bit in front of the shoulder). */
    private static Vec3 muzzle(ServerPlayer p, int slot) {
        Vec3 look = p.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        double side = slot == 1 ? 0.5 : -0.5;
        return p.getEyePosition().add(right.scale(side)).add(0, -0.3, 0).add(look.scale(0.7));
    }

    private static Vec3 rotateY(Vec3 v, double ang) {
        double c = Math.cos(ang), s = Math.sin(ang);
        return new Vec3(v.x * c - v.z * s, v.y, v.x * s + v.z * c);
    }

    /**
     * Hit-scan beam. Aims at the point the crosshair would hit so the shot converges on the target.
     * @return the end point of the beam
     */
    private static Vec3 fireBeam(ServerPlayer p, CyberData d, Vec3 from, Vec3 dir, double range, float dmg,
                                 boolean pierce, double width, Vector3f color, float size, float blastRadius) {
        ServerLevel l = (ServerLevel) p.level();
        Vec3 eye = p.getEyePosition();
        Vec3 aimEnd = eye.add(dir.scale(range));
        BlockHitResult bh = l.clip(new ClipContext(eye, aimEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 stop = bh.getType() == HitResult.Type.MISS ? aimEnd : bh.getLocation();

        // direction from the muzzle to the converge point
        Vec3 shotDir = stop.subtract(from);
        if (shotDir.lengthSqr() < 0.01) shotDir = dir;
        shotDir = shotDir.normalize();
        Vec3 end = from.add(shotDir.scale(Math.max(1.0, stop.distanceTo(from))));

        // entities along the segment
        AABB sweep = new AABB(from, end).inflate(width + 1.0);
        List<LivingEntity> hits = new ArrayList<>();
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, sweep, e -> e != p && e.isAlive())) {
            if (e.getBoundingBox().inflate(width * 0.5).clip(from, end).isPresent()) hits.add(e);
        }
        hits.sort(Comparator.comparingDouble(e -> e.distanceToSqr(from)));

        float total = dmg * d.damageMul();
        for (LivingEntity e : hits) {
            e.hurt(p.damageSources().playerAttack(p), total);
            Vec3 kb = shotDir.scale(pierce ? 0.9 : 0.5);
            e.push(kb.x, 0.25, kb.z);
            e.hurtMarked = true;
            if (pierce) e.setSecondsOnFire(4);
            if (!pierce) {   // blue beam stops on the first target
                end = e.getBoundingBox().inflate(0.1).clip(from, end).orElse(e.position());
                break;
            }
        }

        Fx.beam(l, from, end, color, size, pierce ? 0.35 : 0.5);
        Fx.burst(l, end, color, pierce ? 40 : 14, 0.25);

        if (blastRadius > 0.9 && pierce) {   // red cannon explodes on impact (never hurts the shooter, never breaks blocks)
            l.sendParticles(ParticleTypes.EXPLOSION, end.x, end.y, end.z, 3, 0.4, 0.4, 0.4, 0);
            Fx.sound(l, end, SoundEvents.GENERIC_EXPLODE, 1.2f, 1.3f);
            for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, new AABB(end, end).inflate(blastRadius),
                    e -> e != p && !hits.contains(e))) {
                e.hurt(p.damageSources().playerAttack(p), total * 0.5f);
            }
        }
        return end;
    }

    /** Melee arc in front of the player. */
    private static void slash(ServerPlayer p, CyberData d, float dmg, double reach, double arcDeg, int side) {
        ServerLevel l = (ServerLevel) p.level();
        Vec3 look = new Vec3(p.getLookAngle().x, 0, p.getLookAngle().z).normalize();
        double cosHalf = Math.cos(Math.toRadians(arcDeg / 2));
        Fx.sound(l, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 1.2f);

        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(reach, 1.0, reach), e -> e != p && e.isAlive())) {
            Vec3 to = new Vec3(e.getX() - p.getX(), 0, e.getZ() - p.getZ());
            double dist = to.length();
            if (dist > reach + e.getBbWidth() * 0.5) continue;
            if (dist > 0.01 && to.normalize().dot(look) < cosHalf) continue;
            e.hurt(p.damageSources().playerAttack(p), dmg * d.damageMul());
            e.push(look.x * 0.7, 0.3, look.z * 0.7);
            e.hurtMarked = true;
        }
        // visible arc
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        for (int i = -6; i <= 6; i++) {
            double a = Math.toRadians(i * arcDeg / 12.0);
            Vec3 dir = look.scale(Math.cos(a)).add(right.scale(Math.sin(a)));
            for (double r = 1.2; r <= reach; r += 0.8) {
                Vec3 o = p.position().add(0, 1.1 + side * 0.2 * (i / 6.0), 0).add(dir.scale(r));
                l.sendParticles(new net.minecraft.core.particles.DustParticleOptions(Fx.BLUE, 1.3f), o.x, o.y, o.z, 1, 0, 0, 0, 0);
            }
        }
        l.sendParticles(ParticleTypes.SWEEP_ATTACK, p.getX() + look.x * 1.5, p.getY() + 1.1, p.getZ() + look.z * 1.5, 1, 0, 0, 0, 0);
    }

    // ============================================================================ jetpack

    private static void thrust(ServerPlayer p, CyberData d) {
        if (d.back != HardpointType.JETPACK || d.overheated()) return;
        float cost = d.energyCost(1.5f);
        if (d.energy < cost) return;
        d.energy -= cost;
        p.fallDistance = 0;
        if (!p.getAbilities().mayfly) {          // server-side only, never synced to the client
            p.getAbilities().mayfly = true;
            JET_FLAG.put(p.getUUID(), p.tickCount);
        } else if (JET_FLAG.containsKey(p.getUUID())) {
            JET_FLAG.put(p.getUUID(), p.tickCount);
        }
        ServerLevel l = (ServerLevel) p.level();
        Vec3 back = new Vec3(-p.getLookAngle().x, 0, -p.getLookAngle().z).normalize();
        Vec3 o = p.position().add(back.scale(0.35)).add(0, 0.9, 0);
        l.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, o.x, o.y - 0.5, o.z, 4, 0.12, 0.25, 0.12, 0.02);
        if (p.tickCount % 6 == 0) Fx.sound(l, p.position(), SoundEvents.FIRE_AMBIENT, 0.7f, 1.8f);
    }

    /** Called every tick for each player so the temporary flight flag is always removed. */
    public static void jetCleanup(ServerPlayer p) {
        Integer last = JET_FLAG.get(p.getUUID());
        if (last != null && p.tickCount - last > 3) restoreFlight(p);
    }

    public static void restoreFlight(ServerPlayer p) {
        if (JET_FLAG.remove(p.getUUID()) != null && !p.isCreative() && !p.isSpectator()) {
            p.getAbilities().mayfly = false;
            p.getAbilities().flying = false;
        }
    }

    // ============================================================================ support / overdrive

    private static void callSupport(ServerPlayer p, CyberData d) {
        if (d.supportCooldown > 0) {
            p.displayClientMessage(Component.translatable("message.cyberarms.support_cd", d.supportCooldown / 20)
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        ServerLevel l = (ServerLevel) p.level();
        Vec3 look = new Vec3(p.getLookAngle().x, 0, p.getLookAngle().z).normalize();
        double x = p.getX() + look.x * 5, z = p.getZ() + look.z * 5;
        if (!l.canSeeSky(BlockPos.containing(x, p.getY() + 1, z))) {
            p.displayClientMessage(Component.translatable("message.cyberarms.need_sky").withStyle(ChatFormatting.RED), true);
            return;
        }
        BlockHitResult down = l.clip(new ClipContext(new Vec3(x, p.getY() + 3, z), new Vec3(x, p.getY() - 8, z),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        double y = down.getType() == HitResult.Type.MISS ? p.getY() : down.getLocation().y;

        SupportPodEntity pod = ModEntities.SUPPORT_POD.get().create(l);
        if (pod == null) return;
        pod.initAt(x, y, z);
        pod.setOwner(p.getUUID());
        l.addFreshEntity(pod);

        d.supportCooldown = CyberData.SUPPORT_COOLDOWN;
        Net.anim(p, 1, "signal");
        Net.anim(p, 0, "signal");
        Fx.sound(l, p.position(), SoundEvents.NOTE_BLOCK_BELL.value(), 2f, 2f);
        p.displayClientMessage(Component.translatable("message.cyberarms.support_called").withStyle(ChatFormatting.AQUA), true);
        Net.sync(p);
    }

    // ============================================================================ unequip

    private static void unequip(ServerPlayer p, CyberData d, boolean everything) {
        give(p, d.left);
        give(p, d.right);
        give(p, d.back);
        d.clearWeapons();
        if (everything) {
            ItemStack core = new ItemStack(ModItems.POWER_CORE.get());
            CoreItem.setColor(core, d.coreColor);
            if (!p.getInventory().add(core)) p.drop(core, false);
            d.hasCore = false;
            d.overdriveTicks = 0;
            restoreFlight(p);
        }
        Net.sync(p);
        p.displayClientMessage(Component.translatable(everything ? "message.cyberarms.removed_all" : "message.cyberarms.removed_weapons"), true);
    }

    private static void give(ServerPlayer p, HardpointType t) {
        if (t == null) return;
        ItemStack s = new ItemStack(switch (t) {
            case BLUE_CANNON -> ModItems.BLUE_CANNON.get();
            case RED_CANNON -> ModItems.RED_CANNON.get();
            case ARM_BLADE -> ModItems.ARM_BLADE.get();
            case JETPACK -> ModItems.JETPACK.get();
        });
        if (!p.getInventory().add(s)) p.drop(s, false);
    }
}
