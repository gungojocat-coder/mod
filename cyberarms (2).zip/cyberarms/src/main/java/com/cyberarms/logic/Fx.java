package com.cyberarms.logic;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Particle / sound helpers shared by every weapon. */
public final class Fx {
    public static final Vector3f BLUE = new Vector3f(0.15f, 0.65f, 1f);
    public static final Vector3f RED = new Vector3f(1f, 0.1f, 0.1f);

    private Fx() {}

    /** Draw a glowing line of dust from a to b. */
    public static void beam(ServerLevel l, Vec3 a, Vec3 b, Vector3f color, float size, double step) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 dir = d.scale(1.0 / len);
        DustParticleOptions o = new DustParticleOptions(color, size);
        for (double t = 0; t <= len; t += step) {
            Vec3 p = a.add(dir.scale(t));
            l.sendParticles(o, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
    }

    public static void burst(ServerLevel l, Vec3 p, Vector3f color, int count, double spread) {
        l.sendParticles(new DustParticleOptions(color, 1.6f), p.x, p.y, p.z, count, spread, spread, spread, 0.05);
        l.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, count / 2, spread, spread, spread, 0.3);
    }

    public static void sound(ServerLevel l, Vec3 p, SoundEvent s, float vol, float pitch) {
        l.playSound(null, p.x, p.y, p.z, s, SoundSource.PLAYERS, vol, pitch);
    }
}
